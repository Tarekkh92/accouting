<p>Hi, This is {{ $data1['contactName'] }}</p>
{{-- <p>I have some query like {{ $data1['message'] }}.</p> --}}
<p>It would be appriciative, if you gone through this feedback.</p>