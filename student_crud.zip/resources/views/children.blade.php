<p> 
    ولد اول
    <br/>
    <label for="">الاسم:</label>
    <span color="green">{{ $data['cname'] }}</span>
    <br/>
    <label for="">عيد ميلاد :</label>
    <span color="green">{{ $data['firstChildDate'] }}</span>
    <br/>
    <label for="">برعايتي:</label>
    <span color="green">{{ $data['protection'] }}</span>
    <br/>
    <label for="">نفقه:</label>
    <span color="green"> {{ $data['supply'] }}</span>
    <br/>
    <label for="">احادي:</label>
    <span color="green">{{ $data['single'] }}</span>
    <br/>
    <label for="">درات خاصة </label>
    <span color="green">{{ $data['needs'] }}</span>
    <br/>
    <label for="">تعليم خاص:</label>
    <span color="green"> {{ $data['specialNeeds'] }}</span>
    <br/>
</p>
<p> 
ولد 2
<br/>
<label for="">الاسم:</label>
<span color="green">{{ $data['cname1'] }}</span>
<br/>
<label for="">عيد ميلاد :</label>
<span color="green">{{ $data['firstChildDate1'] }}</span>
<br/>
<label for="">برعايتي:</label>
<span color="green">{{ $data['protection1'] }}</span>
<br/>
<label for="">نفقه:</label>
<span color="green"> {{ $data['supply1'] }}</span>
<br/>
<label for="">احادي:</label>
<span color="green">{{ $data['single1'] }}</span>
<br/>
<label for="">درات خاصة </label>
<span color="green">{{ $data['needs1'] }}</span>
<br/>
<label for="">تعليم خاص:</label>
<span color="green"> {{ $data['specialNeeds1'] }}</span>
<br/>
</p>
<p> 
ولد 3
<br/>
<label for="">الاسم:</label>
<span color="green">{{ $data['cname2'] }}</span>
<br/>
<label for="">عيد ميلاد :</label>
    <span color="green">{{ $data['firstChildDate2'] }}</span>
    <br/>
<label for="">برعايتي:</label>
<span color="green">{{ $data['protection2'] }}</span>
<br/>
<label for="">نفقه:</label>
<span color="green"> {{ $data['supply2'] }}</span>
<br/>
<label for="">احادي:</label>
<span color="green">{{ $data['single2'] }}</span>
<br/>
<label for="">درات خاصة </label>
<span color="green">{{ $data['needs2'] }}</span>
<br/>
<label for="">تعليم خاص:</label>
<span color="green"> {{ $data['specialNeeds2'] }}</span>
<br/>
</p>

<p> 
ولد 4
<br/>
<label for="">الاسم:</label>
<span color="green">{{ $data['cname3'] }}</span>
<br/>
<label for="">عيد ميلاد :</label>
        <span color="green">{{ $data['firstChildDate3'] }}</span>
        <br/>
<label for="">برعايتي:</label>
<span color="green">{{ $data['protection3'] }}</span>
<br/>
<label for="">نفقه:</label>
<span color="green"> {{ $data['supply3'] }}</span>
<br/>
<label for="">احادي:</label>
<span color="green">{{ $data['single3'] }}</span>
<br/>
<label for="">درات خاصة </label>
<span color="green">{{ $data['needs3'] }}</span>
<br/>
<label for="">تعليم خاص:</label>
<span color="green"> {{ $data['specialNeeds3'] }}</span>
<br/>
</p>
<p> 
ولد 5
<br/>
<label for="">الاسم:</label>
<span color="green">{{ $data['cname4'] }}</span>
<br/>
<label for="">عيد ميلاد :</label>
    <span color="green">{{ $data['firstChildDate4'] }}</span>
    <br/>
<label for="">برعايتي:</label>
<span color="green">{{ $data['protection4'] }}</span>
<br/>
<label for="">نفقه:</label>
<span color="green"> {{ $data['supply4'] }}</span>
<br/>
<label for="">احادي:</label>
<span color="green">{{ $data['single4'] }}</span>
<br/>
<label for="">درات خاصة </label>
<span color="green">{{ $data['needs4'] }}</span>
<br/>
<label for="">تعليم خاص:</label>
<span color="green"> {{ $data['specialNeeds4'] }}</span>
<br/>
</p>
{{-- children --}}