<p>Hi, This is <?php echo e($data1['contactName']); ?></p>

<p>It would be appriciative, if you gone through this feedback.</p><?php /**PATH C:\xampp\htdocs\student_crud\student_crud\resources\views/dynamic_contact_template.blade.php ENDPATH**/ ?>