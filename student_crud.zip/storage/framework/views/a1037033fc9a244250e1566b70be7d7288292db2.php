<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <!-- CSS only -->

    <style>
    span{
        color: green;
    }
    body{
        text-align: center;
    }
    table{
        border: 1;
    }
    </style>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body >
    <p> 
        وضعك الاجتماعي:    

        <span color="green"><?php echo e($data['وضع']); ?></span>
    </p>
    <p> 
       لديك ولاد:  

        <span color="green"><?php echo e($data['haveChildren']); ?></span>
    </p>
    <p> 
        لقب:
 
         <span color="green"><?php echo e($data['degree']); ?></span>
     </p>
     <p> 
       فرص سكن
 
         <span color="green"><?php echo e($data['housing']); ?></span>
     </p>
     <p> 
      :جنسيه
  
          <span color="green"><?php echo e($data['gender']); ?></span>
      </p>
      <p> 
        تاريخ الميلاد
    
            <span color="green"><?php echo e($data['dob']); ?></span>
        </p>
        <p> 
            تاريخ الزواج
        
                <span color="green"><?php echo e($data['marriageDate']); ?></span>
        </p>
        <p> 
            تاريخ الطلاق
        
                <span color="green"><?php echo e($data['devorceDate']); ?></span>
        </p>

            <p> 
                هل تدفع نفقة:
            
                    <span color="green"><?php echo e($data['pay']); ?></span>
         </p>
         <div style="overflow-x:auto;" >
         <table border="1" >
            <tr>
              <th>الاسم</th>
              <th>عيد ميلاد </th>
              <th>الولد تحت رعايتي	</th>
              <th>ادفع عنه نفقة		</th>
              <th>انا اب\ ام احادي لهذا الولد	</th>
              <th>ولد ذو عجز\ قدرات خاصة</th>
              <th>اولد يتعلم في تعليم خاص</th>
            </tr>
            <tr>
              <td>  <span color="green"><?php echo e($data['cname']); ?></span> </td>
              <td><span color="green"><?php echo e($data['firstChildDate']); ?></span></td>
              <td> <span color="green"><?php echo e($data['protection']); ?></span></td>
              <td> <span color="green"> <?php echo e($data['supply']); ?></span></td>
              <td>     <span color="green"><?php echo e($data['single']); ?></span></td>
              <td> <span color="green"><?php echo e($data['needs']); ?></span></td>
              <td>   <span color="green"> <?php echo e($data['specialNeeds']); ?></span></td>
            </tr>
            <tr>
                <td>  <span color="green"><?php echo e($data['cname1']); ?></span> </td>
                <td><span color="green"><?php echo e($data['firstChildDate1']); ?></span></td>
                <td> <span color="green"><?php echo e($data['protection1']); ?></span></td>
                <td> <span color="green"> <?php echo e($data['supply1']); ?></span></td>
                <td>     <span color="green"><?php echo e($data['single1']); ?></span></td>
                <td> <span color="green"><?php echo e($data['needs1']); ?></span></td>
                <td>   <span color="green"> <?php echo e($data['specialNeeds1']); ?></span></td>
            </tr>
            <tr>
                <td>  <span color="green"><?php echo e($data['cname2']); ?></span> </td>
                <td><span color="green"><?php echo e($data['firstChildDate2']); ?></span></td>
                <td> <span color="green"><?php echo e($data['protection2']); ?></span></td>
                <td> <span color="green"> <?php echo e($data['supply2']); ?></span></td>
                <td>     <span color="green"><?php echo e($data['single2']); ?></span></td>
                <td> <span color="green"><?php echo e($data['needs2']); ?></span></td>
                <td>   <span color="green"> <?php echo e($data['specialNeeds2']); ?></span></td>
            </tr>
            <tr>
                <td>  <span color="green"><?php echo e($data['cname2']); ?></span> </td>
                <td><span color="green"><?php echo e($data['firstChildDate2']); ?></span></td>
                <td> <span color="green"><?php echo e($data['protection3']); ?></span></td>
                <td> <span color="green"> <?php echo e($data['supply3']); ?></span></td>
                <td>     <span color="green"><?php echo e($data['single3']); ?></span></td>
                <td> <span color="green"><?php echo e($data['needs3']); ?></span></td>
                <td>   <span color="green"> <?php echo e($data['specialNeeds3']); ?></span></td>
            </tr>
            <tr>
                <td>  <span color="green"><?php echo e($data['cname4']); ?></span> </td>
                <td><span color="green"><?php echo e($data['firstChildDate4']); ?></span></td>
                <td> <span color="green"><?php echo e($data['protection4']); ?></span></td>
                <td> <span color="green"> <?php echo e($data['supply4']); ?></span></td>
                <td>     <span color="green"><?php echo e($data['single4']); ?></span></td>
                <td> <span color="green"><?php echo e($data['needs4']); ?></span></td>
                <td>   <span color="green"> <?php echo e($data['specialNeeds4']); ?></span></td>
            </tr>
           
          </table>
        </div>
          


<p> 
    تبرعت لجمعية خيرية ولدي وصل:

        <span><?php echo e($data['مبارعه']); ?></span>
</p>
<p> 
    ادفع لتامين حياة \ تامين منزل:


        <span><?php echo e($data['تامين']); ?></span>
</p>
<p> 
    انا \ زوجي لدينا مصلحة خاصة: 


        <span><?php echo e($data['مصلحة']); ?></span>
</p>
<p> 
    لا انا \ زوجي عاجز بنسبة 90 %على الأقل:  


        <span><?php echo e($data['عاجز']); ?></span>
</p>
<p> 
    بعت عقار\ أرض ودفعت ضريبة: 

        <span><?php echo e($data['ضريبة']); ?></span>
</p>
<p> 
    بعت عقار\ أرض ودفعت ضريبة: 

        <span><?php echo e($data['ضريبة']); ?></span>
</p>
<p> 
    بأي سنوات أنت \ زوجك صاحب مصلحة؟ 
    <br/>
        <span><?php echo e($data['fourteen']); ?>,</span>
        <span><?php echo e($data['fifteen']); ?>,</span>
       <span><?php echo e($data['sixteen']); ?></span>
        <span><?php echo e($data['seventeen']); ?>,</span>
       <span><?php echo e($data['eighteen']); ?>,</span>
       <span><?php echo e($data['nineteen']); ?>,</span>
       <span><?php echo e($data['twenty']); ?>,</span>
</p>
<p> 
    هل قدمت في الماضي طلب لاسترجاع ضريبة او قدمت تقرير سنوي لضريبة الدخل؟ 
    <br/>
        <span><?php echo e($data['تقرير']); ?></span>
</p>
<p> 
    في أي سنوات قدمت؟ 
    <br/>
        <span><?php echo e($data['fourteen1']); ?>,</span>
        <span><?php echo e($data['fifteen1']); ?>,</span>
       <span><?php echo e($data['sixteen1']); ?></span>
        <span><?php echo e($data['seventeen1']); ?>,</span>
       <span><?php echo e($data['eighteen1']); ?>,</span>
       <span><?php echo e($data['nineteen1']); ?>,</span>
       <span><?php echo e($data['twenty1']); ?>,</span>
</p>
<p> 
    لأي سنوات تريد تقديم طلب السترجاع ضريبة؟ 
    <br/>
        <span><?php echo e($data['fourteen2']); ?>,</span>
        <span><?php echo e($data['fifteen2']); ?>,</span>
       <span><?php echo e($data['sixteen2']); ?></span>
        <span><?php echo e($data['seventeen2']); ?>,</span>
       <span><?php echo e($data['eighteen2']); ?>,</span>
       <span><?php echo e($data['nineteen2']); ?>,</span>
       <span><?php echo e($data['twenty2']); ?>,</span>
</p>
<p> 
    اكتب هنا أماكن العمل التي عملت بها:

    <br/>
        <span><?php echo e($data['work1']); ?>,</span>
        <span><?php echo e($data['work2']); ?>,</span>
       <span><?php echo e($data['work3']); ?></span>
        <span><?php echo e($data['work4']); ?>,</span>
       <span><?php echo e($data['work4']); ?>,</span>
       <span><?php echo e($data['work6']); ?>,</span>
      
</p>
<p> 
    كنت عاطل عن العمل خلال السنة 
    <br/>
        <span><?php echo e($data['a']); ?>,</span>
        <span><?php echo e($data['b']); ?>,</span>
       <span><?php echo e($data['b']); ?></span>
        <span><?php echo e($data['d']); ?>,</span>
       <span><?php echo e($data['e']); ?>,</span>
       <span><?php echo e($data['f']); ?>,</span>
       <span><?php echo e($data['g']); ?>,</span>
      
</p>
<p> 
    كم كان معدل راتبك الشهري في الست سنوات الأخيرة: 
    <br/>
        <span><?php echo e($data['salaryRange']); ?></span>
</p>


<p> 
    حصلت على دخل ايجار من شقة او محل املكه؟ 
    <br/>
        <span><?php echo e($data['own']); ?></span>
</p>
<p> 
    كنت عاطل عن العمل خلال السنة 
    <br/>
        <span><?php echo e($data['a1']); ?>,</span>
        <span><?php echo e($data['a2']); ?>,</span>
       <span><?php echo e($data['a3']); ?></span>
        <span><?php echo e($data['a4']); ?>,</span>
       <span><?php echo e($data['a5']); ?>,</span>
       <span><?php echo e($data['a6']); ?>,</span>
       <span><?php echo e($data['a7']); ?>,</span>
      
</p>
<p> 
    من أي صندوق توفير سحبت؟

    <br/>
        <span><?php echo e($data['box']); ?></span>
</p>
<p> 
    سحبت اتعابك ومستحقات عمل؟ 
    <br/>
        <span><?php echo e($data['withdraw']); ?></span>
</p>
<p> 
    هل حسابك الجاري في البنك مرهون؟ 
    <br/>
        <span><?php echo e($data['inlineRadioOptions']); ?></span>
</p>

<p> 
    هل لديك ديون او ملفات مفتوحة؟ 
    <br/>
        <span><?php echo e($data['debt']); ?></span>
</p>
<p> 
    هل لديك ديون او ملفات مفتوحة؟ 
    <br/>
        <span><?php echo e($data['inlineRadioOptions1']); ?></span>
</p>



    <!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
</body>
</html>



<?php /**PATH C:\xampp\htdocs\student_crud\student_crud\resources\views/dynamic_email_template.blade.php ENDPATH**/ ?>